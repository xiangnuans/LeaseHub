import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Sender, SendMode, toNano } from '@ton/core';

export const OperationCodes = {
    transferNft: 0x5fcc3d14,
    getStaticData: 0x2fcb26a2,
    emergencyTransfer: 555,
};

export interface NftMarketplaceConfig {
    ownerAddress: Address;
    collectionAddress: Address;
    nftSaleCode: Cell;
}

export function nftMarketplaceConfigToCell(config: NftMarketplaceConfig) {
    return beginCell()
        .storeAddress(config.ownerAddress)
        .storeAddress(config.collectionAddress)
        .storeRef(config.nftSaleCode)
        .endCell();
}

export class NftMarketplace implements Contract {
    constructor(
        readonly address: Address,
        readonly init?: { code: Cell; data: Cell },
    ) { }

    static createFromAddress(address: Address) {
        return new NftMarketplace(address);
    }

    static createFromConfig(config: NftMarketplaceConfig, code: Cell, workchain = 0) {
        const data = nftMarketplaceConfigToCell(config);
        const init = { code, data };
        return new NftMarketplace(contractAddress(workchain, init), init);
    }

    async sendDeploy(provider: ContractProvider, via: Sender) {
        await provider.internal(via, {
            value: toNano(0.05),
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

    async getMarketData(provider: ContractProvider) {
        const { stack } = await provider.get('get_market_data', []);
        return {
            ownerAddress: stack.readAddress(),
            contractAddress: stack.readAddress(),
            nftSaleCode: stack.readCell(),
        };
    }

    async getSaleAddress(provider: ContractProvider, nftAddress: Address, nftOwner: Address, salePrice: bigint) {
        const { stack } = await provider.get('get_sale_address', [{
            type: 'slice',
            cell: beginCell().storeAddress(nftAddress).endCell(),
        }, {
            type: 'slice',
            cell: beginCell().storeAddress(nftOwner).endCell(),
        }, {
            type: 'int',
            value: salePrice,
        }]);
        return stack.readAddress();
    }
}
