import { Address, beginCell, Cell, Contract, ContractProvider, Sender, SendMode } from '@ton/core';

export const OperationCodes = {
    Transfer: 0x5fcc3d14,
    DoSale: 0x0fe0ede,
}

export class NftItem implements Contract {
    constructor(
        readonly address: Address,
        readonly init?: { code: Cell; data: Cell },
    ) { }

    static createFromAddress(address: Address) {
        return new NftItem(address);
    }

    async sendListing(provider: ContractProvider, via: Sender,
        opts: {
            value: bigint,
            newOwner: Address,
            forwardAmount: bigint,
            fullPrice: bigint,
        }
    ) {
        const msgBody = beginCell()
            .storeUint(OperationCodes.Transfer, 32)
            .storeUint(Date.now(), 64)
            .storeAddress(opts.newOwner)
            .storeAddress(via.address)
            .storeBit(0)
            .storeCoins(opts.forwardAmount)
            .storeBit(0) // we store forward_payload is this cell
            .storeUint(OperationCodes.DoSale, 31)
            .storeCoins(opts.fullPrice)
            .endCell();

        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: msgBody,
        });
    }

    async getNftData(provider: ContractProvider) {
        const result = await provider.get('get_nft_data', []);

        return {
            init: result.stack.readBoolean(),
            index: result.stack.readNumber(),
            collectionAddress: result.stack.readAddress(),
            ownerAddress: result.stack.readAddress(),
            content: result.stack.readCell(),
        };
    }
}
