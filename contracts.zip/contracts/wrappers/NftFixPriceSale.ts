import {
    Address,
    beginCell,
    Cell,
    Contract,
    contractAddress,
    ContractProvider,
    Sender,
    SendMode,
    toNano,
} from '@ton/core';

export const OperationCodes = {
    Deploy: 1,
    Purchase: 2,
    DeListingNft: 3,
    ChangePrice: 0x6c6c2080,
    OwnershipAssigned: 0x05138d91,
    TransferNft: 0x5fcc3d14,
    EmergencyTransfer: 555,
};

export type NftFixPriceSaleData = {
    isComplete: boolean;
    createdAt: number;
    collectionAddress: Address;
    nftAddress: Address;
    nftOwnerAddress: Address | null;
    fullPrice: bigint;
    soldAt: number;
    queryId: number;
};

export function nftFixPriceSaleConfigToCell(config: NftFixPriceSaleData): Cell {
    return beginCell()
        .storeUint(config.isComplete ? 1 : 0, 1)
        .storeUint(config.createdAt, 32)
        .storeAddress(config.collectionAddress)
        .storeAddress(config.nftAddress)
        .storeAddress(config.nftOwnerAddress)
        .storeCoins(config.fullPrice)
        .storeUint(config.soldAt, 32)
        .storeUint(config.queryId, 64)
        .endCell();
}

export class NftFixPriceSale implements Contract {
    constructor(
        readonly address: Address,
        readonly init?: { code: Cell; data: Cell },
    ) { }

    static createFromAddress(address: Address) {
        return new NftFixPriceSale(address);
    }

    async sendPurchase(
        provider: ContractProvider,
        via: Sender,
        opts: {
            value: bigint;
            queryId: number;
        },
    ) {
        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(OperationCodes.Purchase, 32)
                .storeUint(opts.queryId, 64)
                .endCell(),
        });
    }

    async sendDeListingNft(
        provider: ContractProvider,
        via: Sender,
        opts: {
            value: bigint;
            queryId: number;
        },
    ) {
        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(OperationCodes.DeListingNft, 32)
                .storeUint(opts.queryId, 64)
                .endCell(),
        });
    }

    async getSaleData(provider: ContractProvider) {
        const result = await provider.get('get_sale_data', []);
        return {
            isComplete: result.stack.readNumber() == -1,
            createdAt: result.stack.readNumber(),
            collectionAddress: result.stack.readAddress(),
            nftAddress: result.stack.readAddress(),
            nftOwnerAddress: result.stack.readAddress(),
            fullPrice: result.stack.readBigNumber(),
            soldAt: result.stack.readNumber(),
            queryId: result.stack.readBigNumber(),
        };
    }
}
