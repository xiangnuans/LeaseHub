import { Address, beginCell, Builder, Cell, Contract, contractAddress, ContractProvider, Dictionary, Sender, SendMode, Slice, toNano } from '@ton/core';
import { decodeOffChainContent, encodeOffChainContent } from './metadata';

export const Opcodes = {
    getRoyaltyParams: 0x693d3950,
    mint: 1,
    batchMint: 2,
    changeOwner: 3,
    changeContent: 4,
    updateMerkleroot: 5,
    cleanClaim: 6,
    destroy: 7,
    updateIndexRangeToPrice: 8,
};

export type FeeParams = {
    factor: number;
    base: number;
    address: Address;
};

export type NftCollectionConfig = {
    ownerAddress: Address;
    nextItemIndex: number;
    collectionContentUrl: string;
    commonContentUrl: string;
    nftItemCode: Cell;
    royaltyParams: FeeParams;
    marketplaceParams: FeeParams;
    maxSupply: number;
    indexRangeToPrice: IndexRangeToPrice[];
    indexRangeWhitelist: IndexRangeWhitelist[];
};

export type AirdropEntry = {
    address: Address;
    amount: number;
};

export const airdropEntryValue = {
    serialize: (src: AirdropEntry, builder: Builder) => {
        builder.storeAddress(src.address).storeUint(src.amount, 64);
    },
    parse: (src: Slice) => {
        return {
            address: src.loadAddress(),
            amount: src.loadUint(64),
        };
    },
};

export function makeMerkleProof(merkleRoot: Cell, entryIndex: number): Cell {
    const dictCell = Cell.fromBase64(makeBocBase64(merkleRoot)); // Dictionary cell boc base64
    const dict = dictCell.beginParse().loadDictDirect(Dictionary.Keys.BigUint(256), airdropEntryValue);
    return dict.generateMerkleProof(BigInt(entryIndex))
}

export function generateEntriesDictionary(entries: AirdropEntry[]): Dictionary<bigint, AirdropEntry> {
    let dict: Dictionary<bigint, AirdropEntry> = Dictionary.empty(Dictionary.Keys.BigUint(256), airdropEntryValue);
    for (let i = 0; i < entries.length; i++) {
        dict.set(BigInt(i), entries[i]);
    }
    return dict;
}

export function makeMerkleRoot(entries: AirdropEntry[]): Cell {
    const dict = generateEntriesDictionary(entries);
    return beginCell().storeDictDirect(dict).endCell();
}

export function makeBocBase64(dictCell: Cell): string {
    return dictCell.toBoc().toString('base64');
}

export function makeHash(dictCell: Cell): bigint {
    return BigInt('0x' + dictCell.hash().toString('hex'));
}

export type IndexRangeWhitelist = {
    startIndex: number;
    endIndex: number;
    merkleRoot: bigint;
    merkleStartTime: number;
    merkleEndTime: number;
}

export const indexRangeWhitelistEntryValue = {
    serialize: (src: IndexRangeWhitelist, builder: Builder) => {
        builder.storeUint(src.startIndex, 64)
            .storeUint(src.endIndex, 64)
            .storeUint(src.merkleRoot, 256)
            .storeUint(src.merkleStartTime, 32)
            .storeUint(src.merkleEndTime, 32);
    },
    parse: (src: Slice) => {
        return {
            startIndex: src.loadUint(64),
            endIndex: src.loadUint(64),
            merkleRoot: src.loadUintBig(256),
            merkleStartTime: src.loadUint(32),
            merkleEndTime: src.loadUint(32),
        };
    },
};

export function generateIndexRangeWhitelistDictionary(entries: IndexRangeWhitelist[]): Dictionary<bigint, IndexRangeWhitelist> {
    let dict: Dictionary<bigint, IndexRangeWhitelist> = Dictionary.empty(Dictionary.Keys.BigUint(64), indexRangeWhitelistEntryValue);
    for (let index = 0; index < entries.length; index++) {
        dict.set(BigInt(index), entries[index]);
    }
    return dict;
}

export type IndexRangeToPrice = {
    startIndex: number;
    endIndex: number;
    price: bigint;
}

export const indexRangeToPriceEntryValue = {
    serialize: (src: IndexRangeToPrice, builder: Builder) => {
        builder.storeUint(src.startIndex, 64)
            .storeUint(src.endIndex, 64)
            .storeCoins(src.price);
    },
    parse: (src: Slice) => {
        return {
            startIndex: src.loadUint(64),
            endIndex: src.loadUint(64),
            price: src.loadCoins(),
        };
    },
};

export function generateIndexRangeToPriceDictionary(entries: IndexRangeToPrice[]): Dictionary<bigint, IndexRangeToPrice> {
    let dict: Dictionary<bigint, IndexRangeToPrice> = Dictionary.empty(Dictionary.Keys.BigUint(64), indexRangeToPriceEntryValue);
    for (let index = 0; index < entries.length; index++) {
        dict.set(BigInt(index), entries[index]);
    }
    return dict;
}

export function makeIndexRangeToPrice(entries: IndexRangeToPrice[]): Cell {
    const dict = generateIndexRangeToPriceDictionary(entries);
    return beginCell().storeDictDirect(dict).endCell();
}

export function nftCollectionConfigToCell(config: NftCollectionConfig): Cell {
    const content = beginCell()
        .storeRef(encodeOffChainContent(config.collectionContentUrl))
        .storeRef(beginCell().storeBuffer(Buffer.from(config.commonContentUrl)).endCell())
        .endCell();

    const feeParams = beginCell()
        .storeUint(config.marketplaceParams.factor, 16)
        .storeUint(config.marketplaceParams.base, 16)
        .storeAddress(config.marketplaceParams.address)
        .storeUint(config.royaltyParams.factor, 16)
        .storeUint(config.royaltyParams.base, 16)
        .storeAddress(config.royaltyParams.address)
        .endCell();

    const merkleConfig = beginCell()
        .storeUint(config.maxSupply, 64)
        .storeDict(generateIndexRangeToPriceDictionary(config.indexRangeToPrice))
        .storeDict(generateIndexRangeWhitelistDictionary(config.indexRangeWhitelist))
        .storeDict(Dictionary.empty())
        .endCell();

    return beginCell()
        .storeAddress(config.ownerAddress)
        .storeUint(config.nextItemIndex, 64)
        .storeRef(content)
        .storeRef(config.nftItemCode)
        .storeRef(feeParams)
        .storeRef(merkleConfig)
        .endCell();
}

export class NftCollection implements Contract {
    constructor(
        readonly address: Address,
        readonly init?: { code: Cell; data: Cell },
    ) { }

    static createFromAddress(address: Address) {
        return new NftCollection(address);
    }

    static createFromConfig(config: NftCollectionConfig, code: Cell, workchain = 0) {
        const data = nftCollectionConfigToCell(config);
        const init = { code, data };
        return new NftCollection(contractAddress(workchain, init), init);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

    async sendDestroy(provider: ContractProvider, via: Sender) {
        await provider.internal(via, {
            value: toNano(0.01),
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.destroy, 32)
                .storeUint(0, 64)
                .endCell(),
        });
    }

    async sendUpdateMerkleroot(provider: ContractProvider, via: Sender, index: number, whitelist: IndexRangeWhitelist) {
        await provider.internal(via, {
            value: toNano(0.01),
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.updateMerkleroot, 32)
                .storeUint(Date.now(), 64)
                .storeUint(index, 64)
                .storeUint(whitelist.startIndex, 64)
                .storeUint(whitelist.endIndex, 64)
                .storeUint(whitelist.merkleRoot, 256)
                .storeUint(whitelist.merkleStartTime, 32)
                .storeUint(whitelist.merkleEndTime, 32)
                .endCell(),
        });
    }

    async sendUpdatePrice(provider: ContractProvider, via: Sender, index: number, whitelist: IndexRangeToPrice) {
        await provider.internal(via, {
            value: toNano(0.01),
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.updateIndexRangeToPrice, 32)
                .storeUint(Date.now(), 64)
                .storeUint(index, 64)
                .storeUint(whitelist.startIndex, 64)
                .storeUint(whitelist.endIndex, 64)
                .storeCoins(whitelist.price)
                .endCell(),
        });
    }

    async sendCleanClaim(provider: ContractProvider, via: Sender) {
        await provider.internal(via, {
            value: toNano(0.01),
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.cleanClaim, 32)
                .storeUint(Date.now(), 64)
                .endCell(),
        });
    }

    async sendMint(
        provider: ContractProvider,
        via: Sender,
        opts: {
            value: bigint,
            queryId: number,
            proof: Cell,
            index: number,
            mintAmount: number,
        },
    ) {
        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.mint, 32)
                .storeUint(opts.queryId, 64)
                .storeRef(opts.proof)
                .storeUint(opts.index, 256)
                .storeUint(opts.mintAmount, 64)
                .endCell(),
        });
    }

    async getCollectionData(provider: ContractProvider): Promise<{
        nextItemIndex: number;
        collectionContentUrl: string;
        ownerAddress: Address;
    }> {
        const { stack } = await provider.get('get_collection_data', []);

        return {
            nextItemIndex: stack.readNumber(),
            collectionContentUrl: decodeOffChainContent(stack.readCell()),
            ownerAddress: stack.readAddress(),
        };
    }

    async getNftAddressByIndex(provider: ContractProvider, index: bigint): Promise<Address> {
        const { stack } = await provider.get('get_nft_address_by_index', [
            {
                type: 'int',
                value: index,
            },
        ]);

        return stack.readAddress();
    }

    async getRoyaltyParams(provider: ContractProvider): Promise<FeeParams> {
        const { stack } = await provider.get('royalty_params', []);

        return {
            factor: stack.readNumber(),
            base: stack.readNumber(),
            address: stack.readAddress(),
        };
    }

    async getMarketplaceParams(provider: ContractProvider): Promise<FeeParams> {
        const { stack } = await provider.get('marketplace_params', []);

        return {
            factor: stack.readNumber(),
            base: stack.readNumber(),
            address: stack.readAddress(),
        };
    }

    async getNftContent(provider: ContractProvider, index: bigint, individualNftContent: Cell): Promise<string> {
        const { stack } = await provider.get('get_nft_content', [
            {
                type: 'int',
                value: index,
            },
            {
                type: 'cell',
                cell: individualNftContent,
            },
        ]);

        return decodeOffChainContent(stack.readCell());
    }

    async getMintPrice(provider: ContractProvider, amount: number): Promise<bigint> {
        const { stack } = await provider.get('get_mint_price', [
            {
                type: 'int',
                value: BigInt(amount),
            },
        ]);

        return stack.readBigNumber();
    }

    async getClaimData(provider: ContractProvider, proof: Cell, index: bigint) {
        const { stack } = await provider.get('get_claim_data', [
            {
                type: 'cell',
                cell: proof,
            },
            {
                type: 'int',
                value: index,
            },
        ]);

        return {
            userAddress: stack.readAddress(),
            alreadyClaimCount: stack.readNumber()
        };
    }

    async getInWhitelistTime(provider: ContractProvider, startIndex: number, endIndex: number) {
        const { stack } = await provider.get('get_in_whitelist_time', [
            {
                type: 'int',
                value: BigInt(startIndex),
            },
            {
                type: 'int',
                value: BigInt(endIndex),
            },
        ]);

        return stack.readBoolean();
    }

    async getMerkleConfig(provider: ContractProvider, startIndex: number, endIndex: number) {
        const { stack } = await provider.get('get_merkle_config', [
            {
                type: 'int',
                value: BigInt(startIndex),
            },
            {
                type: 'int',
                value: BigInt(endIndex),
            },
        ]);

        return {
            merkleRoot: stack.readBigNumber(),
            startTime: stack.readNumber(),
            endTime: stack.readNumber(),
            found: stack.readBoolean(),
        }
    }

    async getAppConfig(provider: ContractProvider) {
        const { stack } = await provider.get('get_app_config', []);
        const maxSupply = stack.readBigNumber();
        const idxConfig = stack.readCell();
        const merkleConfig = stack.readCell();
        return {
            maxSupply,
            idxConfig: idxConfig.beginParse().loadDictDirect(Dictionary.Keys.BigUint(64), indexRangeToPriceEntryValue),
            merkleConfig: merkleConfig.beginParse().loadDictDirect(Dictionary.Keys.BigUint(64), indexRangeWhitelistEntryValue),
        }
    }
}
