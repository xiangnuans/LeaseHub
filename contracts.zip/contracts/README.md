# TON NFT Contracts

### 配置说明

nft里的json文件以及对应的图片，到时候统一放在同一目录里
mint的时候不用管mint第几个，内部会自动加1

后台NFT集合需要配置两个地址：

* 集合配置文件规范：http://miniapp.url/$collectionId/colleciton-meta.json
* NFT配置统一目录：http://miniapp.url/$collectionId/nft/

到时候，后台要生成N个合约需要用到的资源地址，这样nft就可以读取了，目录大概这样：

1. 第1个NFT
    * http://miniapp.url/$collectionId/nft/1/1.json
    * http://miniapp.url/$collectionId/nft/1/1.jpeg

2. 第2个NFT
    * http://miniapp.url/$collectionId/nft/2/2.json
    * http://miniapp.url/$collectionId/nft/2/2.jpeg

3. 第3个NFT
    * http://miniapp.url/$collectionId/nft/3/3.json
    * http://miniapp.url/$collectionId/nft/3/3.jpeg

4. 如此类推

### 配置参考说明

> nft-contract 配置参考：https://nft.ton.diamonds/octopus-boyz/octopusboyz.json


> nft-item 配置参考

目录规范：$url/$index/$index.json

配置参考：https://nft.ton.diamonds/octopus-boyz/nft/1/1.json


### 合约说明

* mint 合约有白名单权限，此处 merkle tree 技术，生成 merkle tree 请参考脚本 [`makeMerkleTree.ts`](./scripts/makeMerkleTree.ts)


nft-collection: EQB2V8PczobjFXl6qCgj3yxuFqmKuTicc8ExGDN4DDbPWkql
nft-marketplace: EQDBHSRUMvvDtKbGonhhJpCikAx5_hQ_1-5GuPLY0-Ihh-JM

