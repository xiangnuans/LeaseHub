import { Address, Cell } from '@ton/core';
import { NftCollection } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { readFileSync } from 'fs';

export async function run(provider: NetworkProvider, args: string[]) {
    const merkleRootData = readFileSync('./temp/merkleRoot.json');
    const merkleRootJson = JSON.parse(merkleRootData.toString()).proofData;

    const sender = provider.sender();

    let index = 0;
    let proof = Cell.fromBase64(merkleRootJson[index].proof);

    const user = merkleRootJson.find((item: any) => item.address === sender.address!.toString());
    if (user != undefined) {
        console.log('User found in merkle root', user);
        index = user.index;
        proof = Cell.fromBase64(user.proof);
    }

    const contract = readFileSync('./temp/nft-collection.json');
    const contractJson = JSON.parse(contract.toString());
    const address = Address.parse(args.length > 0 ? args[args.length - 1] : contractJson.address);

    const nftCollection = provider.open(NftCollection.createFromAddress(address));

    const mintAmount = 1;
    const mintPrice = await nftCollection.getMintPrice(mintAmount);
    await nftCollection.sendMint(sender, {
        value: mintPrice,
        queryId: Date.now(),
        proof,
        index,
        mintAmount,
    });

    await provider.waitForDeploy(nftCollection.address);
}
