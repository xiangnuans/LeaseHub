import { address, Address, toNano } from '@ton/core';
import { NetworkProvider } from '@ton/blueprint';
import { NftItem } from '../wrappers/NftItem';
import { readFileSync } from 'fs';

export async function run(provider: NetworkProvider, args: string[]) {
    const ui = provider.ui();
    const deployer = provider.sender();

    const contract = readFileSync('./temp/nft-market.json');
    const contractJson = JSON.parse(contract.toString());
    const nftMarket = address(contractJson.address);
    
    const nftAddress = Address.parse(args.length > 0 ? args[args.length - 1] : await ui.input('Nft address:'));

    const nft = provider.open(NftItem.createFromAddress(nftAddress));

    await nft.sendListing(deployer, {
        value: toNano(0.08),
        newOwner: nftMarket,
        forwardAmount: toNano(0.05),
        fullPrice: toNano(1),
    })

    await provider.waitForDeploy(nft.address);
}
