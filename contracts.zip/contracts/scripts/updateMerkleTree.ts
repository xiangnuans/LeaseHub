import { Address, Cell, toNano } from '@ton/core';
import { makeHash, NftCollection } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { readFileSync } from 'fs';

export async function run(provider: NetworkProvider, args: string[]) {
    const merkleRootData = readFileSync('./temp/merkleRoot.json');
    const merkleRootJson = JSON.parse(merkleRootData.toString());

    const contract = readFileSync('./temp/nft-collection.json');
    const contractJson = JSON.parse(contract.toString());
    const address = Address.parse(args.length > 0 ? args[args.length - 1] : contractJson.address);

    const nftCollection = provider.open(NftCollection.createFromAddress(address));

    const merkleStartTime = Math.floor(Date.now() / 1000);
    await nftCollection.sendUpdateMerkleroot(provider.sender(), 0, {
        startIndex: 0,
        endIndex: 1000,
        merkleRoot: makeHash(Cell.fromBase64(merkleRootJson.merkleRoot)),
        merkleStartTime,
        merkleEndTime: merkleStartTime + 86400 * 365,
    });

    await provider.waitForDeploy(nftCollection.address);
}
