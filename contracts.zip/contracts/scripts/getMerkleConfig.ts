import { Address } from '@ton/core';
import { NftCollection } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { readFileSync } from 'fs';

export async function run(provider: NetworkProvider, args: string[]) {
  const contract = readFileSync('./temp/nft-collection.json');
  const contractJson = JSON.parse(contract.toString());
  const address = Address.parse(args.length > 0 ? args[args.length - 1] : contractJson.address);

  const nftCollection = provider.open(NftCollection.createFromAddress(address));

  // const res = await nftCollection.getMerkleConfig(0,1000000);
  // console.log("🚀 ~ run ~ res:", res)

  const startItemIndex = 0;
  const endItemIndex = 20000;
  const config = await nftCollection.getMerkleConfig(startItemIndex, endItemIndex);
  console.log(config);

  if (config.startTime > 0) {
    console.log('startTime:', new Date(config.startTime * 1000).toLocaleString());
    console.log('endTime:', new Date(config.endTime * 1000).toLocaleString());
  }

  const inWhitelistTime = await nftCollection.getInWhitelistTime(startItemIndex, endItemIndex);
  console.log('inWhitelistTime:', inWhitelistTime);

  const appConfig = await nftCollection.getAppConfig();
  // console.log('appConfig:', JSON.stringify(appConfig));  


  console.log('maxSupply:', appConfig.maxSupply.toString());

  // 打印 idxConfig
  console.log('idxConfig:');
  for (const [key, value] of appConfig.idxConfig) {
    console.log(`Key: ${key.toString()}`, `Value: ${JSON.stringify(value, (key, val) =>
      typeof val === 'bigint' ? val.toString() : val, 2)}`);
  }

  // 打印 merkleConfig
  console.log('merkleConfig:');
  for (const [key, value] of appConfig.merkleConfig) {
    console.log(`Key: ${key.toString()}`, `Value: ${JSON.stringify(value, (key, val) =>
      typeof val === 'bigint' ? val.toString() : val, 2)}`);
  }

  // await provider.waitForDeploy(nftCollection.address);
}
