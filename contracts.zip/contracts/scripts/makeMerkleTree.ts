import { Address } from '@ton/core';
import { AirdropEntry, makeBocBase64, makeMerkleProof, makeMerkleRoot } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { writeFileSync } from 'fs';

export interface ProofData {
    index: number,
    proof: string,
    address: string,
}

export interface Result {
    merkleRoot: string,
    proofData: ProofData[]
}

export async function run(provider: NetworkProvider) {
    const deployer = provider.sender();

    const airdropUser1 = Address.parse('EQAt-ijcfQmuImEgdTLKmvo0hDryR6cOFAD1_X3v1pDaVF4u');
    const airdropUser2 = Address.parse('EQCiUSSbX6sv0HIbVH0No5rfNRzJXaD4nKjXIUxkKC_di-0e');
    const airdropUser3 = Address.parse('0QAFSI_rtOlLXKtzn6vHPfGic0Tnds_tolVA9riMKwPruZa6');
    const airdropUser4 = Address.parse('0QD5hXnd9cOHe7cnSoxnGJi6uDuGs_iEmqQVnxsg2RyKQXaH'); // Tonkeeper(chroma)
    const airdropUser5 = Address.parse('0QCeHbUpGm98B6KNo9_k0qKimzr5FaJ6XBJ1K9tzVv0-F91p'); // Tonkeeper(tg)



    const airdropEntries: AirdropEntry[] = [
        {
            address: deployer.address!, // whitelist address
            amount: 1_000_000 // nft amount
        },
        {
            address: airdropUser1, // whitelist address
            amount: 1 // nft amount
        },
        {
            address: airdropUser2, // whitelist address
            amount: 1000 // nft amount
        },
        {
            address: airdropUser3, // whitelist address
            amount: 1000 // nft amount
        },
        {
            address: airdropUser4, // whitelist address
            amount: 1000 // nft amount
        },
        {
            address: airdropUser5, // whitelist address
            amount: 1000 // nft amount
        },
    ];

    const merkleRoot = makeMerkleRoot(airdropEntries);

    const proofData: ProofData[] = []
    for (let index = 0; index < airdropEntries.length; index++) {
        const proof = makeMerkleProof(merkleRoot, index);
        proofData.push({
            index,
            proof: makeBocBase64(proof),
            address: airdropEntries[index].address.toString()
        });
    }

    const result: Result = {
        merkleRoot: makeBocBase64(merkleRoot),
        proofData,
    }
    writeFileSync('./temp/merkleRoot.json', JSON.stringify(result, null, 4));
}
