import { Address, toNano } from '@ton/core';
import { NetworkProvider } from '@ton/blueprint';
import { NftFixPriceSale } from '../wrappers/NftFixPriceSale';
import { NftItem } from '../wrappers/NftItem';

export async function run(provider: NetworkProvider, args: string[]) {
    const ui = provider.ui();

    const address = Address.parse(args.length > 0 ? args[args.length - 1] : await ui.input('NFT address:'));

    const nftItem = provider.open(NftItem.createFromAddress(address));
    const nftData = await nftItem.getNftData();

    const sale = provider.open(NftFixPriceSale.createFromAddress(nftData.ownerAddress));
    await sale.sendPurchase(provider.sender(), {
        value: toNano(1.1),
        queryId: Date.now(),
    });
    await provider.waitForDeploy(sale.address);
}
