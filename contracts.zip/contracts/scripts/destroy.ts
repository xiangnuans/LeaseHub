import { Address } from '@ton/core';
import { NftCollection } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { readFileSync } from 'fs';

export async function run(provider: NetworkProvider, args: string[]) {
    const contract = readFileSync('./temp/nft-collection.json');
    const contractJson = JSON.parse(contract.toString());
    const address = Address.parse(args.length > 0 ? args[args.length - 1] : contractJson.address);

    const nftCollection = provider.open(NftCollection.createFromAddress(address));

    await nftCollection.sendDestroy(provider.sender());

    await provider.waitForDeploy(nftCollection.address);
}
