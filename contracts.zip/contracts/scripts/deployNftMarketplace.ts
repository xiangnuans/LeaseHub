import { NetworkProvider } from '@ton/blueprint';
import { NftMarketplace } from '../wrappers/NftMarketplace';
import { readFileSync, writeFileSync } from 'fs';
import { readContract } from '../wrappers/metadata';
import { Address } from '@ton/core';

export async function run(provider: NetworkProvider) {
    const contract = readFileSync('./temp/nft-collection.json');
    const contractJson = JSON.parse(contract.toString());
    const collectionAddress = Address.parse(contractJson.address);

    const deployer = provider.sender();

    const nftMarket = provider.open(NftMarketplace.createFromConfig({
        ownerAddress: deployer.address!,
        collectionAddress,
        nftSaleCode: readContract('NftFixPriceSale')
    }, readContract('NftMarketplace')));
    await nftMarket.sendDeploy(deployer);

    writeFileSync('./temp/nft-market.json', JSON.stringify({
        address: nftMarket.address.toString()
    }, null, 4));

    await provider.waitForDeploy(nftMarket.address);
}
