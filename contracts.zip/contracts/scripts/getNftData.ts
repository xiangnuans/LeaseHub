import { Address } from '@ton/core';
import { NetworkProvider } from '@ton/blueprint';
import { NftItem } from '../wrappers/NftItem';

export async function run(provider: NetworkProvider, args: string[]) {
    const ui = provider.ui();

    const address = Address.parse(args.length > 0 ? args[args.length - 1] : await ui.input('NFT address:'));
    
    const nftItem = provider.open(NftItem.createFromAddress(address));
    const nftData = await nftItem.getNftData();
    console.log('NFT data:', nftData)
}
