import { Cell, toNano } from '@ton/core';
import { makeHash, NftCollection } from '../wrappers/NftCollection';
import { NetworkProvider } from '@ton/blueprint';
import { readFileSync, writeFileSync } from 'fs';
import { readContract } from '../wrappers/metadata';

export async function run(provider: NetworkProvider) {
    const deployer = provider.sender();

    const merkleRootData = readFileSync('./temp/merkleRoot.json');
    const merkleRootJson = JSON.parse(merkleRootData.toString());

    // refer to makeMerkleTree.ts
    const merkleRoot = Cell.fromBase64(merkleRootJson.merkleRoot);

    const merkleStartTime = Math.floor(Date.now() / 1000);
    const nftCollection = provider.open(
        NftCollection.createFromConfig(
            {
                ownerAddress: deployer.address!,
                nextItemIndex: 0, //起始从0开始
                collectionContentUrl: 'https://nft.ton.diamonds/octopus-boyz/octopusboyz.json',
                commonContentUrl: 'https://nft.ton.diamonds/octopus-boyz/nft/',
                nftItemCode: readContract('NftItem'),
                royaltyParams: {
                    factor: 10,
                    base: 100,
                    address: deployer.address!,
                },
                marketplaceParams: {
                    factor: 5,
                    base: 1000,
                    address: deployer.address!,
                },
                maxSupply: 720_000,
                indexRangeToPrice: [{
                    startIndex: 0,
                    endIndex: 1000,
                    price: toNano(0.2),
                },{
                    startIndex: 1001,
                    endIndex: 2000,
                    price: toNano(1),
                },{
                    startIndex: 2001,
                    endIndex: 3000,
                    price: toNano(2),
                }],
                indexRangeWhitelist: [{
                    startIndex: 0,
                    endIndex: 1000,
                    merkleRoot: makeHash(merkleRoot),
                    merkleStartTime,
                    merkleEndTime: merkleStartTime + 86400 * 365,
                }]
            },
            readContract('NftCollection'),
        ),
    );

    await nftCollection.sendDeploy(provider.sender(), toNano(0.05));

    writeFileSync('./temp/nft-collection.json', JSON.stringify({
        address: nftCollection.address.toString()
    }, null, 4));

    await provider.waitForDeploy(nftCollection.address);

    // run methods on `nftCollection`
    const data = await nftCollection.getCollectionData();
    console.log('NftCollectionData:', data);
}
